/**
 * @file
 * Global utilities.
 *
 */
(function ($, Drupal) {

  'use strict';

  Drupal.behaviors.iplan_b4 = {
    attach: function (context, settings) {

    }
  };

})(jQuery, Drupal);
